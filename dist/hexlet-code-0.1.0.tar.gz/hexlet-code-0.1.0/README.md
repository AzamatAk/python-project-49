### Hexlet tests and linter status:

[![Maintainability](<a href="https://codeclimate.com/github/AzamatAk/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c6fa73cafe3e858b92f7/maintainability" /></a>)]


[![Actions Status](https://github.com/AzamatAk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AzamatAk/python-project-49/actions)

brain-even: https://asciinema.org/a/oCuKXIZNQFLgfnw7N3Ix1qHAA

brain-calc: https://asciinema.org/a/RCarqlDC087Le27Ge68PbtwbB
