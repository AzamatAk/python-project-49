# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n\n[![Maintainability](<a href="https://codeclimate.com/github/AzamatAk/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c6fa73cafe3e858b92f7/maintainability" /></a>)]\n\n\n[![Actions Status](https://github.com/AzamatAk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AzamatAk/python-project-49/actions)\n\nbrain-even: https://asciinema.org/a/oCuKXIZNQFLgfnw7N3Ix1qHAA\n\nbrain-calc: https://asciinema.org/a/RCarqlDC087Le27Ge68PbtwbB\n',
    'author': 'Azamat',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
